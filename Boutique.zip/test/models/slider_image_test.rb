require 'test_helper'

class SliderImageTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
