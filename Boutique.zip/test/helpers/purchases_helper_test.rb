require 'test_helper'

class PurchasesHelperTest < ActionView::TestCase
end
