require 'test_helper'

class SliderImagesHelperTest < ActionView::TestCase
end
