require 'test_helper'

class MessageMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
