require 'test_helper'

class CartProductControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
