# Be sure to restart your server when you modify this file.

Boutique::Application.config.session_store :cookie_store, key: '_Boutique_session'
