# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Boutique::Application.config.secret_key_base = '56bacc35a1a9932f8e51690e0981f0644e9c0f988e3eb90cf608e3560155ba274c65bd68524fe67a58497f56ceef2ed9d689be2be8d22bd66ddd1ae07dea889e'
